"""
Vercel Serverless Python Entrypoint for Matrix8
Handles /api/config, /api/register, /api/verify-deposit, /api/user-dashboard
"""

import sys
import os
import json
import urllib.parse
from http.server import BaseHTTPRequestHandler

# Add backend folder to path
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT_DIR, 'backend'))

import database
import matrix_service
import bsc_verifier

# Initialize database
database.init_db()

class handler(BaseHTTPRequestHandler):
    def send_json(self, data, status=200):
        body = json.dumps(data).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        query = urllib.parse.parse_qs(parsed.query)

        if parsed.path.endswith('/config'):
            self.send_json({
                'treasury_address': database.SYSTEM_TREASURY_ADDRESS,
                'usdt_contract': bsc_verifier.BSC_USDT_CONTRACT,
                'registration_fee_usdt': matrix_service.REGISTRATION_FEE,
                'levels_count': 8
            })
            return

        elif parsed.path.endswith('/user-dashboard'):
            user_id = query.get('user_id', [None])[0] or database.SYSTEM_ROOT_ID
            dashboard = matrix_service.get_user_dashboard(user_id)
            if dashboard:
                self.send_json(dashboard)
            else:
                self.send_json({'error': 'User not found'}, status=404)
            return

        self.send_json({'error': 'API Route Not Found'}, status=404)

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        content_len = int(self.headers.get('Content-Length', 0))
        body = json.loads(self.rfile.read(content_len).decode('utf-8')) if content_len > 0 else {}

        if parsed.path.endswith('/register'):
            email = body.get('email', '')
            password = body.get('password', '')
            sponsor_id = body.get('sponsor_id', '')
            wallet_address = body.get('wallet_address', '')
            telegram = body.get('telegram_handle', '')

            try:
                result = matrix_service.register_user(
                    email=email,
                    password=password,
                    sponsor_id=sponsor_id,
                    wallet_address=wallet_address,
                    telegram_handle=telegram
                )
                self.send_json({'success': True, 'data': result})
            except Exception as e:
                self.send_json({'success': False, 'error': str(e)}, status=400)
            return

        elif parsed.path.endswith('/verify-deposit'):
            user_id = body.get('user_id', '')
            tx_hash = body.get('tx_hash', '').strip()
            is_mock = body.get('is_mock_test', False)

            if not user_id:
                self.send_json({'success': False, 'error': 'Missing user_id'}, status=400)
                return

            if not is_mock:
                verification = bsc_verifier.verify_bsc_deposit(tx_hash)
                if not verification.get('verified'):
                    self.send_json({'success': False, 'error': verification.get('error', 'Verification failed')}, status=400)
                    return

            try:
                activation = matrix_service.activate_user_and_distribute(user_id, tx_hash)
                self.send_json({'success': True, 'data': activation})
            except Exception as e:
                self.send_json({'success': False, 'error': str(e)}, status=400)
        elif parsed.path.endswith('/login'):
            email = body.get('email', '')
            credential = body.get('credential', '') or body.get('password', '') or body.get('wallet_address', '')

            try:
                user = matrix_service.login_user(email=email, credential=credential)
                self.send_json({'success': True, 'data': user})
            except Exception as e:
                self.send_json({'success': False, 'error': str(e)}, status=400)
            return

        self.send_json({'error': 'API Route Not Found'}, status=404)
