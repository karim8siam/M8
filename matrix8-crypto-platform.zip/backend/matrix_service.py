"""
Matrix8 Core Commission & Matrix Logic (Backend)
Handles 8-Level Upline Traversal, Commission Dispatches, and SQLite Updates.
"""

import time
import random
import hashlib
from database import get_db, SYSTEM_ROOT_ID, SYSTEM_TREASURY_ADDRESS

LEVEL_PERCENTAGES = [0.21, 0.16, 0.13, 0.09, 0.06, 0.03, 0.02, 0.01]
REGISTRATION_FEE = 3.40
SYSTEM_BASE_PERCENTAGE = 0.29

def hash_password(password):
    return hashlib.sha256(password.encode('utf-8')).hexdigest()

def generate_unique_id():
    conn = get_db()
    cursor = conn.cursor()
    while True:
        num = random.randint(100000, 999999)
        uid = f"M8-{num}"
        cursor.execute('SELECT unique_id FROM users WHERE unique_id = ?', (uid,))
        if not cursor.fetchone():
            conn.close()
            return uid

def register_user(email, password, sponsor_id, wallet_address, telegram_handle=''):
    conn = get_db()
    cursor = conn.cursor()

    email_clean = email.strip().lower()
    wallet_clean = wallet_address.strip()
    raw_sponsor = sponsor_id.strip().upper()
    if raw_sponsor in ('ADMIN', 'M8-ADMIN', 'M8-VIP001'):
        sponsor_clean = 'M8-ADMIN'
    else:
        sponsor_clean = raw_sponsor

    # Check unique email
    cursor.execute('SELECT unique_id FROM users WHERE email = ?', (email_clean,))
    if cursor.fetchone():
        conn.close()
        raise ValueError('This email address is already registered.')

    # Check unique wallet
    cursor.execute('SELECT unique_id FROM users WHERE LOWER(wallet_address) = LOWER(?)', (wallet_clean,))
    if cursor.fetchone():
        conn.close()
        raise ValueError('This BEP-20 wallet address is already linked to an account.')

    # Check sponsor exists
    cursor.execute('SELECT unique_id, status FROM users WHERE unique_id = ?', (sponsor_clean,))
    sponsor = cursor.fetchone()
    if not sponsor:
        conn.close()
        raise ValueError(f'Sponsor ID "{sponsor_clean}" does not exist in the network.')

    new_id = generate_unique_id()
    now = int(time.time())
    is_admin_link = (sponsor_clean == 'M8-ADMIN')
    initial_status = 'ACTIVE' if is_admin_link else 'PENDING_DEPOSIT'

    # Insert user
    cursor.execute('''
        INSERT INTO users (
            unique_id, email, password_hash, wallet_address, referrer_id,
            telegram_handle, status, join_timestamp, total_earned, wallet_balance, directs_count
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0.0, 0.0, 0)
    ''', (
        new_id,
        email_clean,
        hash_password(password),
        wallet_clean,
        sponsor_clean,
        telegram_handle or '',
        initial_status,
        now
    ))

    # Initialize 8-level stats
    for lvl in range(1, 9):
        cursor.execute('''
            INSERT INTO level_stats (user_id, level_num, member_count, earned_amount)
            VALUES (?, ?, 0, 0.0)
        ''', (new_id, lvl))

    # If joining via Admin link: 100% Free Instant VIP Activation
    if is_admin_link:
        cursor.execute('UPDATE users SET directs_count = directs_count + 1 WHERE unique_id = ?', (sponsor_clean,))
        cursor.execute('UPDATE level_stats SET member_count = member_count + 1 WHERE user_id = ? AND level_num = 1', (sponsor_clean,))
        
        cursor.execute('''
            INSERT INTO transactions (
                tx_hash, tx_type, from_user_id, to_user_id, from_wallet, to_wallet,
                amount_usdt, timestamp, status, note
            ) VALUES (?, 'ADMIN_VIP_FREE_JOIN', ?, ?, ?, ?, 0.0, ?, 'CONFIRMED', '★ Admin VIP Free Activation (0 USDT Required)')
        ''', (
            f"ADMIN_VIP_{new_id}_{now}",
            new_id,
            sponsor_clean,
            wallet_clean,
            SYSTEM_TREASURY_ADDRESS,
            now
        ))

    conn.commit()
    conn.close()

    return {
        'unique_id': new_id,
        'email': email_clean,
        'wallet_address': wallet_clean,
        'sponsor_id': sponsor_clean,
        'status': initial_status,
        'is_free_vip': is_admin_link,
        'treasury_deposit_address': SYSTEM_TREASURY_ADDRESS,
        'required_amount_usdt': 0.0 if is_admin_link else REGISTRATION_FEE
    }

def activate_user_and_distribute(user_id, tx_hash):
    conn = get_db()
    cursor = conn.cursor()

    # Check replay attack
    cursor.execute('SELECT id FROM transactions WHERE tx_hash = ?', (tx_hash,))
    if cursor.fetchone():
        conn.close()
        raise ValueError(f'This Transaction Hash ({tx_hash[:10]}...) has already been verified and used.')

    cursor.execute('SELECT * FROM users WHERE unique_id = ?', (user_id,))
    user = cursor.fetchone()
    if not user:
        conn.close()
        raise ValueError(f'User {user_id} not found.')

    if user['status'] == 'ACTIVE':
        conn.close()
        return {'status': 'ALREADY_ACTIVE', 'unique_id': user_id}

    # Activate user
    cursor.execute('UPDATE users SET status = "ACTIVE" WHERE unique_id = ?', (user_id,))

    # Log the incoming 3.4 USDT deposit
    now = int(time.time())
    cursor.execute('''
        INSERT INTO transactions (
            tx_hash, tx_type, from_user_id, to_user_id, from_wallet, to_wallet,
            amount_usdt, timestamp, status, note
        ) VALUES (?, 'BSC_DEPOSIT', ?, ?, ?, ?, ?, ?, 'CONFIRMED', '3.40 USDT Activation Deposit Confirmed on BSC')
    ''', (
        tx_hash,
        user_id,
        SYSTEM_ROOT_ID,
        user['wallet_address'],
        SYSTEM_TREASURY_ADDRESS,
        REGISTRATION_FEE,
        now
    ))

    # Update Direct Sponsor count
    sponsor_id = user['referrer_id']
    if sponsor_id:
        cursor.execute('UPDATE users SET directs_count = directs_count + 1 WHERE unique_id = ?', (sponsor_id,))

    # 8-Tier Recursive Commission Loop
    current_upline_id = sponsor_id
    distributed_sum = 0.0
    orphaned_percentage = 0.0
    commissions = []

    for level_idx in range(8):
        pct = LEVEL_PERCENTAGES[level_idx]
        commission_amount = round(REGISTRATION_FEE * pct, 4)
        level_num = level_idx + 1

        if current_upline_id and current_upline_id != SYSTEM_ROOT_ID:
            cursor.execute('SELECT * FROM users WHERE unique_id = ?', (current_upline_id,))
            upline = cursor.fetchone()
            if upline:
                # Credit upline total earned & wallet balance
                cursor.execute('''
                    UPDATE users 
                    SET total_earned = total_earned + ?, wallet_balance = wallet_balance + ?
                    WHERE unique_id = ?
                ''', (commission_amount, commission_amount, current_upline_id))

                # Update 8-level stats
                cursor.execute('''
                    UPDATE level_stats 
                    SET member_count = member_count + 1, earned_amount = earned_amount + ?
                    WHERE user_id = ? AND level_num = ?
                ''', (commission_amount, current_upline_id, level_num))

                # Log commission tx
                sub_tx_hash = f"{tx_hash}_L{level_num}"
                cursor.execute('''
                    INSERT INTO transactions (
                        tx_hash, tx_type, from_user_id, to_user_id, from_wallet, to_wallet,
                        amount_usdt, level_num, timestamp, status, note
                    ) VALUES (?, 'COMMISSION_PAYOUT', ?, ?, ?, ?, ?, ?, ?, 'CONFIRMED', ?)
                ''', (
                    sub_tx_hash,
                    user_id,
                    upline['unique_id'],
                    user['wallet_address'],
                    upline['wallet_address'],
                    commission_amount,
                    level_num,
                    now,
                    f"Level {level_num} Commission ({int(pct * 100)}%) - ${commission_amount} USDT"
                ))

                commissions.append({
                    'level': level_num,
                    'upline_id': upline['unique_id'],
                    'upline_wallet': upline['wallet_address'],
                    'amount_usdt': commission_amount,
                    'percentage': pct * 100
                })

                distributed_sum += commission_amount
                current_upline_id = upline['referrer_id']
            else:
                orphaned_percentage += pct
                current_upline_id = None
        else:
            orphaned_percentage += pct
            if current_upline_id:
                cursor.execute('SELECT referrer_id FROM users WHERE unique_id = ?', (current_upline_id,))
                row = cursor.fetchone()
                current_upline_id = row['referrer_id'] if row else None

    # System Treasury Base (29%) + Orphaned Levels Fallback
    base_system = round(REGISTRATION_FEE * SYSTEM_BASE_PERCENTAGE, 4)
    orphaned_fee = round(REGISTRATION_FEE * orphaned_percentage, 4)
    total_system = round(base_system + orphaned_fee, 4)

    cursor.execute('''
        UPDATE users 
        SET total_earned = total_earned + ?, wallet_balance = wallet_balance + ?
        WHERE unique_id = ?
    ''', (total_system, total_system, SYSTEM_ROOT_ID))

    cursor.execute('''
        INSERT INTO transactions (
            tx_hash, tx_type, from_user_id, to_user_id, from_wallet, to_wallet,
            amount_usdt, timestamp, status, note
        ) VALUES (?, 'SYSTEM_TREASURY', ?, ?, ?, ?, ?, ?, 'CONFIRMED', ?)
    ''', (
        f"{tx_hash}_SYS",
        user_id,
        SYSTEM_ROOT_ID,
        user['wallet_address'],
        SYSTEM_TREASURY_ADDRESS,
        total_system,
        now,
        f"Treasury Base (${base_system}) + Orphan Fallback (${orphaned_fee})"
    ))

    conn.commit()
    conn.close()

    # Trigger automated Web3 BEP-20 payout dispatcher after DB commit
    try:
        import payout_dispatcher
        for c in commissions:
            payout_dispatcher.dispatch_usdt_payout(
                to_wallet=c['upline_wallet'],
                amount_usdt=c['amount_usdt'],
                level_num=c['level'],
                from_user_id=user_id,
                to_user_id=c['upline_id']
            )
    except Exception as e:
        print(f"Payout dispatch note: {e}")

    return {
        'status': 'ACTIVATED',
        'unique_id': user_id,
        'tx_hash': tx_hash,
        'commissions_distributed': commissions,
        'total_system_fee': total_system
    }

def get_user_dashboard(user_id):
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute('SELECT * FROM users WHERE unique_id = ?', (user_id,))
    user = cursor.fetchone()
    if not user:
        conn.close()
        return None

    # Fetch 8 level stats
    cursor.execute('SELECT level_num, member_count, earned_amount FROM level_stats WHERE user_id = ? ORDER BY level_num ASC', (user_id,))
    levels = [dict(row) for row in cursor.fetchall()]

    # Fetch recent transactions
    cursor.execute('''
        SELECT * FROM transactions 
        WHERE to_user_id = ? OR from_user_id = ?
        ORDER BY timestamp DESC LIMIT 20
    ''', (user_id, user_id))
    txs = [dict(row) for row in cursor.fetchall()]

    # Aggregate total downlines
    total_downlines = sum(l['member_count'] for l in levels)

    conn.close()
    return {
        'unique_id': user['unique_id'],
        'email': user['email'],
        'wallet_address': user['wallet_address'],
        'status': user['status'],
        'total_earned': user['total_earned'],
        'wallet_balance': user['wallet_balance'],
        'directs_count': user['directs_count'],
        'total_downlines': total_downlines,
        'referrer_id': user['referrer_id'],
        'levels': levels,
        'level_stats': levels,
        'transactions': txs,
        'treasury_address': SYSTEM_TREASURY_ADDRESS
    }

def login_user(email, credential):
    """
    Authenticates a user via registered Gmail/Email + (Password OR BEP-20 Wallet Address).
    If either the password hash OR the BEP-20 wallet address matches, login is granted.
    """
    conn = get_db()
    cursor = conn.cursor()

    email_clean = email.strip().lower()
    cred_clean = credential.strip()

    if not email_clean or not cred_clean:
        conn.close()
        raise ValueError("Please provide your registered Email and either your Password or BEP-20 Wallet Address.")

    cursor.execute('SELECT * FROM users WHERE LOWER(email) = ?', (email_clean,))
    user = cursor.fetchone()
    conn.close()

    if not user:
        raise ValueError("No account found with this email address. Please verify your email or register.")

    # Check Password Match OR BEP-20 Wallet Address Match
    pw_hash = hash_password(cred_clean)
    password_matches = (user['password_hash'] == pw_hash)
    wallet_matches = (user['wallet_address'].strip().lower() == cred_clean.lower())

    if not password_matches and not wallet_matches:
        raise ValueError("Invalid credentials. Please enter your correct Password or registered BEP-20 Wallet Address.")

    return {
        'unique_id': user['unique_id'],
        'email': user['email'],
        'wallet_address': user['wallet_address'],
        'status': user['status'],
        'total_earned': user['total_earned'],
        'wallet_balance': user['wallet_balance'],
        'referrer_id': user['referrer_id'],
        'is_registered': True
    }

