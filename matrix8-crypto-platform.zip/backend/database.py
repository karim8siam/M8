"""
Matrix8 SQLite Database Engine
Stores users, upline network relationships, on-chain deposits, and 8-tier commissions.
"""

import sqlite3
import os
import json
import time

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'matrix8.db')
SYSTEM_TREASURY_ADDRESS = '0x9ff36bB1b16F1421b2CeBFFE311aCB8D5800AE43'
SYSTEM_ROOT_ID = 'M8-VIP001'

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()

    # Users Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            unique_id TEXT PRIMARY KEY,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            wallet_address TEXT NOT NULL,
            referrer_id TEXT,
            telegram_handle TEXT,
            status TEXT DEFAULT 'ACTIVE', -- 'PENDING_DEPOSIT' or 'ACTIVE'
            join_timestamp INTEGER NOT NULL,
            total_earned REAL DEFAULT 0.0,
            wallet_balance REAL DEFAULT 0.0,
            directs_count INTEGER DEFAULT 0
        )
    ''')

    # 8-Level Metrics Table per user
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS level_stats (
            user_id TEXT NOT NULL,
            level_num INTEGER NOT NULL,
            member_count INTEGER DEFAULT 0,
            earned_amount REAL DEFAULT 0.0,
            PRIMARY KEY (user_id, level_num)
        )
    ''')

    # Transactions & Commissions Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tx_hash TEXT UNIQUE,
            tx_type TEXT NOT NULL, -- 'BSC_DEPOSIT', 'COMMISSION_PAYOUT', 'SYSTEM_TREASURY'
            from_user_id TEXT,
            to_user_id TEXT,
            from_wallet TEXT,
            to_wallet TEXT,
            amount_usdt REAL NOT NULL,
            level_num INTEGER,
            timestamp INTEGER NOT NULL,
            status TEXT DEFAULT 'CONFIRMED',
            note TEXT
        )
    ''')

    # System Metrics Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS system_config (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    ''')

    # Insert Genesis Root Admin nodes (M8-ADMIN, M8-VIP001)
    admin_ids = ['M8-ADMIN', 'M8-VIP001', 'ADMIN']
    for admin_id in admin_ids:
        cursor.execute('SELECT unique_id FROM users WHERE unique_id = ?', (admin_id,))
        if not cursor.fetchone():
            cursor.execute('''
                INSERT INTO users (
                    unique_id, email, password_hash, wallet_address, referrer_id,
                    telegram_handle, status, join_timestamp, total_earned, wallet_balance, directs_count
                ) VALUES (?, ?, ?, ?, ?, ?, 'ACTIVE', ?, 0.0, 0.0, 0)
            ''', (
                admin_id,
                f'{admin_id.lower()}@matrix8.io',
                'admin_hash',
                SYSTEM_TREASURY_ADDRESS,
                None,
                '@Matrix8Official',
                int(time.time())
            ))

            for lvl in range(1, 9):
                cursor.execute('''
                    INSERT OR IGNORE INTO level_stats (user_id, level_num, member_count, earned_amount)
                    VALUES (?, ?, 0, 0.0)
                ''', (admin_id, lvl))

    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_db()
    print("Database initialized successfully at:", DB_PATH)
