/**
 * Matrix8 Application Controller
 * Production BEP-20 Matrix Engine, User Dashboard, On-Chain Verification, and Strict Member Isolation.
 * GUESTS NEVER SEE ADMIN DATA. Dashboard is only shown to authenticated real members.
 */

class AppController {
  constructor() {
    this.matrixEngine = new window.MatrixEngine();
    this.walletService = new window.WalletService(this.matrixEngine);
    this.authService = new window.AuthService(this.matrixEngine);
    this.telegramService = new window.TelegramService(this.matrixEngine);

    this.pendingUser = null;
    this.authMode = 'register'; // 'register' or 'login'

    this.init();
  }

  init() {
    this.bindEvents();
    this.checkUrlReferral();
    this.renderView();
  }

  bindEvents() {
    // Navigation tabs
    document.querySelectorAll('.nav-tab-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const tab = btn.dataset.tab;
        if (tab === 'tab-overview') {
          this.showUserDashboard();
        } else if (tab) {
          this.switchTab(tab);
        }
      });
    });

    // Copy Referral Link
    const btnCopyRefLink = document.getElementById('btnCopyRefLink');
    if (btnCopyRefLink) {
      btnCopyRefLink.addEventListener('click', () => this.copyReferralLink());
    }
  }

  switchAuthMode(mode) {
    this.authMode = mode;
    const regContainer = document.getElementById('authRegisterContainer');
    const loginContainer = document.getElementById('authLoginContainer');
    const tabReg = document.getElementById('toggleTabRegister');
    const tabLogin = document.getElementById('toggleTabLogin');

    if (mode === 'login') {
      if (regContainer) regContainer.style.display = 'none';
      if (loginContainer) loginContainer.style.display = 'block';

      if (tabLogin) {
        tabLogin.style.background = 'var(--primary-cyan)';
        tabLogin.style.color = '#fff';
      }
      if (tabReg) {
        tabReg.style.background = 'transparent';
        tabReg.style.color = 'var(--text-secondary)';
      }
    } else {
      if (regContainer) regContainer.style.display = 'block';
      if (loginContainer) loginContainer.style.display = 'none';

      if (tabReg) {
        tabReg.style.background = 'var(--primary-emerald)';
        tabReg.style.color = '#fff';
      }
      if (tabLogin) {
        tabLogin.style.background = 'transparent';
        tabLogin.style.color = 'var(--text-secondary)';
      }
    }
  }

  checkUrlReferral() {
    const urlParams = new URLSearchParams(window.location.search);
    const ref = urlParams.get('ref');
    if (ref) {
      const inputSponsor = document.getElementById('regSponsorId');
      if (inputSponsor) {
        inputSponsor.value = ref.trim().toUpperCase();
      }
    }
    this.checkSponsorVipStatus();
  }


  checkSponsorVipStatus() {
    const inputSponsor = document.getElementById('regSponsorId');
    const vipContainer = document.getElementById('vipFreeBadgeContainer');
    const feeBadge = document.getElementById('regFeeBadge');
    const btnText = document.getElementById('btnRegisterText');

    if (!inputSponsor) return;
    const sponsorVal = inputSponsor.value.trim().toUpperCase();
    const isAdmin = ['M8-ADMIN', 'ADMIN', 'M8-VIP001'].includes(sponsorVal);

    if (isAdmin) {
      if (vipContainer) vipContainer.style.display = 'block';
      if (feeBadge) feeBadge.textContent = '0.00 USDT (FREE VIP)';
      if (btnText) btnText.textContent = '🚀 Free Instant VIP Activation (0 USDT) ➔';
    } else {
      if (vipContainer) vipContainer.style.display = 'none';
      if (feeBadge) feeBadge.textContent = '3.40 USDT (BEP20)';
      if (btnText) btnText.textContent = 'Pay 3.4 USDT & Activate Membership';
    }
  }

  renderView() {
    const urlParams = new URLSearchParams(window.location.search);
    const ref = urlParams.get('ref');
    const savedUserId = localStorage.getItem(this.authService.SESSION_KEY);

    if (savedUserId && !['M8-ADMIN', 'ADMIN', 'M8-VIP001'].includes(savedUserId)) {
      // Real member session exists -> Open Member Dashboard
      this.showUserDashboard();
    } else {
      // Guest visitor -> Open Landing / Registration & Login Page
      if (ref) {
        this.switchAuthMode('register');
      }
      this.showRegistrationPage();
    }
  }

  showRegistrationPage() {
    const onboardingView = document.getElementById('onboardingView');
    const dashboardView = document.getElementById('dashboardView');
    const navTabs = document.getElementById('navTabs');
    const navGuestBar = document.getElementById('navGuestBar');
    const navUserBar = document.getElementById('navUserBar');

    if (onboardingView) onboardingView.style.display = 'block';
    if (dashboardView) dashboardView.style.display = 'none';
    if (navTabs) navTabs.style.display = 'none';
    if (navGuestBar) navGuestBar.style.display = 'flex';
    if (navUserBar) navUserBar.style.display = 'none';

    this.checkSponsorVipStatus();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async showUserDashboard(passedUser = null) {
    const onboardingView = document.getElementById('onboardingView');
    const dashboardView = document.getElementById('dashboardView');
    const navTabs = document.getElementById('navTabs');
    const navGuestBar = document.getElementById('navGuestBar');
    const navUserBar = document.getElementById('navUserBar');

    let user = passedUser || this.authService.getCurrentUser();
    let userId = user ? (user.unique_id || user.uniqueId) : localStorage.getItem(this.authService.SESSION_KEY);
    
    // Guard: Guests or unauthenticated visitors must never see the dashboard
    if (!userId || ['M8-ADMIN', 'ADMIN', 'M8-VIP001'].includes(userId)) {
      this.showRegistrationPage();
      return;
    }

    if (onboardingView) onboardingView.style.display = 'none';
    if (dashboardView) dashboardView.style.display = 'block';
    if (navTabs) navTabs.style.display = 'flex';
    if (navGuestBar) navGuestBar.style.display = 'none';
    if (navUserBar) navUserBar.style.display = 'flex';

    document.querySelectorAll('.nav-tab-btn').forEach(b => {
      b.classList.toggle('active', b.id === 'tabBtnDashboard');
    });

    try {
      const res = await fetch(`/api/user-dashboard?user_id=${userId}`);
      if (res.ok) {
        const liveData = await res.json();
        this.renderLiveDashboardData(liveData);
        this.switchTab('tab-overview');
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
      }
    } catch (e) {
      console.warn('Backend live dashboard fetch note:', e);
    }

    if (!user && this.matrixEngine) {
      user = this.matrixEngine.getUserById(userId);
    }

    if (user) {
      this.renderDashboardData(user);
      this.renderMatrixCards(user);
      this.renderReferralHub(user);
      this.renderRecentActivity();
      this.renderTelegramLogs();
      this.renderSystemTreasury();
      this.switchTab('tab-overview');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      this.showRegistrationPage();
    }
  }

  renderLiveDashboardData(data) {
    if (!data) return;
    const elEarned = document.getElementById('kpiTotalEarned');
    const elTotal = document.getElementById('kpiTotalMembers');
    const elDirect = document.getElementById('kpiDirectCount');
    const elNavId = document.getElementById('navUserUniqueId');
    const elNavWallet = document.getElementById('navWalletAddressShort');
    const elRefId = document.getElementById('refCardUniqueId');
    const elRefInput = document.getElementById('refLinkInput');
    const elKpiWallet = document.getElementById('kpiWalletAddressShort');

    if (elEarned) elEarned.textContent = `$${(data.total_earned || 0).toFixed(4)} USDT`;
    if (elTotal) elTotal.textContent = data.total_downlines || 0;
    if (elDirect) elDirect.textContent = data.directs_count || 0;

    if (elNavId) elNavId.textContent = data.unique_id;
    if (elRefId) elRefId.textContent = data.unique_id;

    if (data.wallet_address) {
      const shortAddr = `${data.wallet_address.slice(0, 6)}...${data.wallet_address.slice(-4)}`;
      if (elNavWallet) elNavWallet.textContent = shortAddr;
      if (elKpiWallet) elKpiWallet.textContent = `${data.wallet_address.slice(0, 8)}...${data.wallet_address.slice(-6)}`;
    }

    if (elRefInput) {
      elRefInput.value = `${window.location.origin}/?ref=${data.unique_id}`;
    }

    // Render 8 level cards from backend levels data
    const container = document.getElementById('matrixGridCards');
    if (container && data.levels) {
      const levelPcts = [21, 16, 13, 9, 6, 3, 2, 1];
      const levelAmounts = [0.714, 0.544, 0.442, 0.306, 0.204, 0.102, 0.068, 0.034];

      container.innerHTML = data.levels.map((lvl, idx) => {
        const isTier1 = lvl.level_num === 1;
        return `
          <div class="level-card ${isTier1 ? 'tier-1' : ''}">
            <div class="level-card-header">
              <span class="level-tag">LEVEL ${lvl.level_num}</span>
              <span class="level-percentage">${levelPcts[idx]}%</span>
            </div>
            <div class="level-amount-per-join">+$${levelAmounts[idx].toFixed(3)} USDT per member</div>
            <div class="level-stats-row">
              <div class="level-stat-box">
                <span class="level-stat-num mono">${lvl.member_count}</span>
                <span class="level-stat-lbl">Members</span>
              </div>
              <div class="level-stat-box">
                <span class="level-stat-num mono" style="color: var(--primary-emerald);">$${(lvl.earned_amount || 0).toFixed(2)}</span>
                <span class="level-stat-lbl">Earned</span>
              </div>
            </div>
          </div>
        `;
      }).join('');
    }

    // Render Recent Transactions
    const feedContainer = document.getElementById('activityFeedList');
    if (feedContainer && data.transactions) {
      if (data.transactions.length === 0) {
        feedContainer.innerHTML = `
          <div style="text-align: center; color: var(--text-muted); padding: 1.5rem; font-size: 0.82rem;">
            No transactions yet. Share your referral link to earn instant commissions!
          </div>
        `;
      } else {
        feedContainer.innerHTML = data.transactions.map(tx => `
          <div class="feed-item">
            <div class="feed-left">
              <div class="feed-icon ${tx.tx_type === 'COMMISSION' ? 'commission' : 'join'}">
                ${tx.tx_type === 'COMMISSION' ? '💰' : '👥'}
              </div>
              <div>
                <div class="feed-title">${tx.note || tx.tx_type}</div>
                <div class="feed-desc mono">${new Date((tx.timestamp || Date.now()/1000) * 1000).toLocaleTimeString()} • ${tx.tx_hash ? tx.tx_hash.slice(0, 10) + '...' : ''}</div>
              </div>
            </div>
            <div class="feed-amount mono">+$${(tx.amount_usdt || 0).toFixed(4)} USDT</div>
          </div>
        `).join('');
      }
    }

    // QR code
    this.renderReferralQr(data.unique_id);
    this.renderTelegramLogs();
    this.renderSystemTreasury();
  }

  renderDashboardData(user) {
    if (!user) return;
    const elEarned = document.getElementById('kpiTotalEarned');
    const elTotal = document.getElementById('kpiTotalMembers');
    const elDirect = document.getElementById('kpiDirectCount');
    const elNavId = document.getElementById('navUserUniqueId');
    const elNavWallet = document.getElementById('navWalletAddressShort');
    const elRefId = document.getElementById('refCardUniqueId');

    if (elEarned) elEarned.textContent = `$${(user.totalEarned || 0).toFixed(4)} USDT`;

    const elKpiWallet = document.getElementById('kpiWalletAddressShort');
    if (elKpiWallet && user.walletAddress) {
      elKpiWallet.textContent = `${user.walletAddress.slice(0, 8)}...${user.walletAddress.slice(-6)}`;
    }

    const totalDownlines = (user.levelMemberCounts || []).reduce((a, b) => a + b, 0);
    if (elTotal) elTotal.textContent = totalDownlines;
    if (elDirect) elDirect.textContent = user.levelMemberCounts ? user.levelMemberCounts[0] : 0;

    if (elNavId) elNavId.textContent = user.uniqueId;
    if (elRefId) elRefId.textContent = user.uniqueId;
    if (elNavWallet && user.walletAddress) {
      elNavWallet.textContent = `${user.walletAddress.slice(0, 6)}...${user.walletAddress.slice(-4)}`;
    }
  }

  renderMatrixCards(user) {
    const container = document.getElementById('matrixGridCards');
    if (!container || !user) return;

    const levelPcts = [21, 16, 13, 9, 6, 3, 2, 1];
    const levelAmounts = [0.714, 0.544, 0.442, 0.306, 0.204, 0.102, 0.068, 0.034];

    let html = '';
    for (let i = 0; i < 8; i++) {
      const levelNum = i + 1;
      const count = user.levelMemberCounts ? user.levelMemberCounts[i] : 0;
      const earned = user.levelEarnings ? user.levelEarnings[i] : 0;
      const isTier1 = levelNum === 1;

      html += `
        <div class="level-card ${isTier1 ? 'tier-1' : ''}">
          <div class="level-card-header">
            <span class="level-tag">LEVEL ${levelNum}</span>
            <span class="level-percentage">${levelPcts[i]}%</span>
          </div>
          <div class="level-amount-per-join">+$${levelAmounts[i].toFixed(3)} USDT per member</div>
          <div class="level-stats-row">
            <div class="level-stat-box">
              <span class="level-stat-num mono">${count}</span>
              <span class="level-stat-lbl">Members</span>
            </div>
            <div class="level-stat-box">
              <span class="level-stat-num mono" style="color: var(--primary-emerald);">$${earned.toFixed(2)}</span>
              <span class="level-stat-lbl">Earned</span>
            </div>
          </div>
        </div>
      `;
    }
    container.innerHTML = html;
  }

  renderReferralHub(user) {
    if (!user) return;
    const refInput = document.getElementById('refLinkInput');
    const refUrl = `${window.location.origin}/?ref=${user.uniqueId}`;
    if (refInput) refInput.value = refUrl;
    this.renderReferralQr(user.uniqueId);
  }

  renderReferralQr(uniqueId) {
    const qrContainer = document.getElementById('qrCodeContainer');
    if (!qrContainer) return;
    qrContainer.innerHTML = '';
    try {
      if (window.QRCode) {
        new window.QRCode(qrContainer, {
          text: `${window.location.origin}/?ref=${uniqueId}`,
          width: 130,
          height: 130
        });
      }
    } catch (err) {}
  }

  copyReferralLink() {
    const input = document.getElementById('refLinkInput');
    if (input) {
      input.select();
      navigator.clipboard.writeText(input.value);
      this.showToast('Referral link copied to clipboard!', 'success');
    }
  }

  copyUserBep20Address() {
    const user = this.authService.getCurrentUser();
    if (user && user.walletAddress) {
      navigator.clipboard.writeText(user.walletAddress);
      this.showToast(`BEP-20 Address (${user.walletAddress.slice(0, 10)}...) copied!`, 'info');
    }
  }

  renderRecentActivity() {
    const container = document.getElementById('activityFeedList');
    if (!container) return;
    const logs = this.matrixEngine.getGlobalLogs().slice(0, 10);
    if (logs.length === 0) {
      container.innerHTML = `
        <div style="text-align: center; color: var(--text-muted); padding: 1.5rem; font-size: 0.82rem;">
          No network transactions yet. Start referring members to see live commissions!
        </div>
      `;
      return;
    }

    const html = logs.map(l => `
      <div class="feed-item">
        <div class="feed-left">
          <div class="feed-icon ${l.type === 'commission' ? 'commission' : 'join'}">
            ${l.type === 'commission' ? '💰' : '👥'}
          </div>
          <div>
            <div class="feed-title">${l.title}</div>
            <div class="feed-desc mono">${new Date(l.timestamp).toLocaleTimeString()} • ${l.details}</div>
          </div>
        </div>
        <div class="feed-amount mono">+$${l.amount.toFixed(4)} USDT</div>
      </div>
    `).join('');
    container.innerHTML = html;
  }

  renderTelegramLogs() {
    const container = document.getElementById('telegramLogsContainer');
    if (!container) return;
    const logs = this.telegramService.getRecentLogs();
    if (logs.length === 0) {
      container.innerHTML = `
        <div style="text-align: center; color: var(--text-muted); padding: 1.5rem; font-size: 0.82rem;">
          No Telegram alerts received yet. When a commission arrives, instant bot pings stream here.
        </div>
      `;
      return;
    }
    const html = logs.map(l => `
      <div class="feed-item" style="margin-bottom: 0.5rem;">
        <div class="feed-left">
          <div class="feed-icon" style="background: rgba(42, 171, 238, 0.15); color: #2AABEE;">✈️</div>
          <div>
            <div class="feed-title">${l.title}</div>
            <div class="feed-desc mono">${new Date(l.timestamp).toLocaleTimeString()} • ${l.details}</div>
          </div>
        </div>
        <div class="feed-amount mono" style="color: #2AABEE;">+$${l.amount.toFixed(4)} USDT</div>
      </div>
    `).join('');
    container.innerHTML = html;
  }

  renderSystemTreasury() {
    const sysData = this.matrixEngine.getSystemTreasury();
    const elCollected = document.getElementById('sysTreasuryCollected');
    const elVolume = document.getElementById('sysTotalVolume');
    if (elCollected) elCollected.textContent = `$${sysData.totalCollectedUsdt.toFixed(2)} USDT`;
    if (elVolume) elVolume.textContent = `$${sysData.totalVolumeUsdt.toFixed(2)} USDT`;
  }

  switchTab(tabId) {
    document.querySelectorAll('.tab-pane').forEach(el => el.style.display = 'none');
    document.querySelectorAll('.nav-tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.tab === tabId);
    });
    const target = document.getElementById(`tabContent-${tabId.replace('tab-', '')}`);
    if (target) target.style.display = 'block';

    if (tabId === 'tab-tree') {
      this.renderNetworkTree();
    }
  }

  renderNetworkTree() {
    const treeContainer = document.getElementById('downlineTreeContainer');
    if (!treeContainer) return;
    const user = this.authService.getCurrentUser();
    if (!user) return;
    const treeData = this.matrixEngine.getTreeData(user.uniqueId);

    let treeHtml = `
      <div class="tree-node-root">
        <div class="tree-node-id" style="font-size: 1rem;">${treeData.uniqueId} (YOU)</div>
        <div class="tree-node-sub mono">${treeData.walletAddress.slice(0, 8)}...${treeData.walletAddress.slice(-6)}</div>
        <div style="font-size: 0.85rem; color: var(--primary-emerald); font-weight: 700; margin-top: 4px;">Earned: $${treeData.totalEarned.toFixed(2)} USDT</div>
      </div>
    `;

    if (treeData.children && treeData.children.length > 0) {
      treeHtml += `<div class="tree-branches">`;
      treeData.children.forEach(c1 => {
        treeHtml += `
          <div style="display: flex; flex-direction: column; align-items: center;">
            <div class="tree-node-child">
              <div class="tree-node-id">${c1.uniqueId} (L1)</div>
              <div class="tree-node-sub mono">${c1.walletAddress.slice(0, 6)}...</div>
              <div style="font-size: 0.7rem; color: var(--primary-cyan); font-weight: 600;">Earned: $${c1.totalEarned.toFixed(2)}</div>
            </div>
        `;
        if (c1.children && c1.children.length > 0) {
          treeHtml += `<div style="display: flex; gap: 0.5rem; margin-top: 1rem;">`;
          c1.children.forEach(c2 => {
            treeHtml += `
              <div class="tree-node-child" style="min-width: 90px; padding: 0.4rem 0.6rem;">
                <div class="tree-node-id" style="font-size: 0.72rem;">${c2.uniqueId} (L2)</div>
                <div class="tree-node-sub mono">${c2.walletAddress.slice(0, 4)}...</div>
              </div>
            `;
          });
          treeHtml += `</div>`;
        }
        treeHtml += `</div>`;
      });
      treeHtml += `</div>`;
    } else {
      treeHtml += `
        <div style="color: var(--text-muted); font-size: 0.85rem; text-align: center; margin-top: 1rem;">
          No downlines yet. Share your referral link with new members!
        </div>
      `;
    }
    treeContainer.innerHTML = treeHtml;
  }

  // --------------------------------------------------------------------------
  // USER LOGIN & LOGOUT (WITH DEVICE PERSISTENCE)
  // --------------------------------------------------------------------------
  async handleLogin() {
    const email = (document.getElementById('loginEmail').value || '').trim();
    const credential = (document.getElementById('loginCredential').value || '').trim();
    const remember = document.getElementById('loginRemember') ? document.getElementById('loginRemember').checked : true;

    if (!email) {
      this.showToast('Please enter your registered Gmail / Email.', 'warning');
      return;
    }
    if (!credential) {
      this.showToast('Please enter your Password OR your registered BEP-20 Wallet Address.', 'warning');
      return;
    }

    try {
      this.showToast('Authenticating credentials...', 'info');
      const user = await this.authService.loginWithBackend(email, credential, remember);
      this.showToast(`🎉 Login successful! Welcome back, ${user.uniqueId}.`, 'success');
      this.showUserDashboard(user);
    } catch (err) {
      this.showToast(err.message || 'Login failed. Please verify your credentials.', 'warning');
    }
  }

  handleLogout() {
    this.authService.logout();
    this.showToast('🚪 Logged out successfully. You can log in or register anytime.', 'info');
    
    // Switch to guest landing page
    this.switchAuthMode('login');
    this.showRegistrationPage();
  }

  // --------------------------------------------------------------------------
  // USER REGISTRATION & REAL BSC PAYMENT VERIFICATION
  // --------------------------------------------------------------------------
  async handleRegister() {
    const email = (document.getElementById('regEmail').value || '').trim();
    const password = (document.getElementById('regPassword').value || '').trim();
    const sponsorId = (document.getElementById('regSponsorId').value || '').trim();
    const bep20Wallet = (document.getElementById('regBep20Wallet').value || '').trim();
    const telegram = (document.getElementById('regTelegram').value || '').trim();

    if (!sponsorId) {
      this.showToast('Please enter a valid Sponsor / Referrer ID.', 'warning');
      return;
    }
    if (!email || !email.includes('@')) {
      this.showToast('Please enter a valid Gmail / Email Address.', 'warning');
      return;
    }
    if (!password) {
      this.showToast('Please enter a Security Password.', 'warning');
      return;
    }
    if (!bep20Wallet || !this.matrixEngine.isValidBep20Address(bep20Wallet)) {
      this.showToast('Please enter a valid BEP-20 Wallet Address (42 characters starting with 0x).', 'warning');
      return;
    }

    try {
      // 1. Register with backend API
      const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          password,
          sponsor_id: sponsorId,
          wallet_address: bep20Wallet,
          telegram_handle: telegram
        })
      });

      const json = await res.json();
      if (!json.success) {
        throw new Error(json.error || 'Registration failed');
      }

      this.pendingUser = json.data;

      // Check if Admin Free VIP Join
      if (json.data.is_free_vip || ['M8-ADMIN', 'ADMIN', 'M8-VIP001'].includes(sponsorId.toUpperCase())) {
        this.authService.saveSession(json.data.unique_id, true);
        this.showToast(`🎉 VIP Activation Complete! Unique ID: ${json.data.unique_id} (100% FREE via Admin Link)`, 'success');
        this.showUserDashboard(json.data);
        return;
      }

      // Render Payment QR Code for MetaMask Treasury Address
      const qrBox = document.getElementById('paymentQrBox');
      if (qrBox) {
        qrBox.innerHTML = '';
        try {
          if (window.QRCode) {
            new window.QRCode(qrBox, {
              text: `ethereum:0x9ff36bB1b16F1421b2CeBFFE311aCB8D5800AE43@56?value=3.4`,
              width: 120,
              height: 120
            });
          }
        } catch (e) {}
      }

      // Open BSC Payment & Verification Modal for non-admin sponsors
      this.openModal('modalPaymentVerify');
      this.showToast(`Account Created (${this.pendingUser.unique_id})! Please send 3.40 USDT to Treasury to complete activation.`, 'info');

    } catch (err) {
      this.showToast(err.message || 'Registration error occurred.', 'warning');
    }
  }

  copyTreasuryAddress() {
    const addr = document.getElementById('payTreasuryAddressInput').value;
    navigator.clipboard.writeText(addr);
    this.showToast('System Treasury BEP-20 address copied to clipboard!', 'info');
  }

  async handleVerifyDeposit() {
    const txHash = (document.getElementById('depositTxHashInput').value || '').trim();
    if (!txHash || !txHash.startsWith('0x')) {
      this.showToast('Please enter a valid 66-character BSC Transaction Hash (0x...)', 'warning');
      return;
    }

    const userId = this.pendingUser ? this.pendingUser.unique_id : null;
    if (!userId) {
      this.showToast('No pending registration found. Please register first.', 'warning');
      return;
    }

    this.showToast('🔍 Checking Binance Smart Chain for 3.40 USDT transfer...', 'info');

    try {
      const res = await fetch('/api/verify-deposit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: userId,
          tx_hash: txHash
        })
      });

      const json = await res.json();
      if (!json.success) {
        throw new Error(json.error || 'On-chain verification failed');
      }

      this.closeModal('modalPaymentVerify');
      this.authService.saveSession(userId, true);
      this.showToast(`🎉 3.40 USDT Verified on BSC! 8-Level Commissions Distributed!`, 'success');
      this.showUserDashboard();

    } catch (err) {
      this.showToast(`⚠️ Verification Failed: ${err.message}`, 'warning');
    }
  }

  openModal(modalId) {
    const el = document.getElementById(modalId);
    if (el) el.classList.add('active');
  }

  closeModal(modalId) {
    const el = document.getElementById(modalId);
    if (el) el.classList.remove('active');
  }

  showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => toast.remove(), 300);
    }, 4500);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  window.App = new AppController();
});
