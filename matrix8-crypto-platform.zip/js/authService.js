/**
 * AuthService - Production BEP-20 Authentication & Persistent Member Session Management
 * Authenticates users via registered Gmail/Email + (Password OR BEP-20 Wallet Address).
 * Pure member isolation: Guests see only the public Landing/Registration page.
 */

class AuthService {
  constructor(matrixEngine) {
    this.matrixEngine = matrixEngine;
    this.SESSION_KEY = 'matrix8_prod_member_auth_session';
    this.currentUser = null;
    this.connectedWallet = null;

    // Clean legacy test sessions
    localStorage.removeItem('matrix8_active_session_id_prod');
    sessionStorage.removeItem('matrix8_active_session_id_prod');

    this.loadSession();
  }

  loadSession() {
    const savedUserId = localStorage.getItem(this.SESSION_KEY) || sessionStorage.getItem(this.SESSION_KEY);
    
    // Never auto-authenticate guests as Admin
    if (!savedUserId || ['M8-ADMIN', 'ADMIN', 'M8-VIP001'].includes(savedUserId)) {
      this.currentUser = null;
      this.connectedWallet = null;
      return;
    }

    if (this.matrixEngine) {
      const user = this.matrixEngine.getUserById(savedUserId);
      if (user) {
        this.currentUser = user;
        this.connectedWallet = user.walletAddress;
      }
    }
  }

  async loginWithBackend(email, credential, remember = true) {
    if (!email || !credential) {
      throw new Error('Please enter your registered Gmail/Email and either your Password or BEP-20 Wallet Address.');
    }

    const response = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: email.trim(), credential: credential.trim() })
    });

    const json = await response.json();
    if (!json.success) {
      throw new Error(json.error || 'Login failed. Invalid credentials.');
    }

    const user = json.data;
    this.currentUser = {
      uniqueId: user.unique_id,
      email: user.email,
      walletAddress: user.wallet_address,
      status: user.status,
      totalEarned: user.total_earned || 0,
      walletBalance: user.wallet_balance || 0,
      referrerId: user.referrer_id,
      isRegistered: true
    };
    this.connectedWallet = user.wallet_address;

    this.saveSession(user.unique_id, remember);

    // Keep matrixEngine in sync
    if (this.matrixEngine && typeof this.matrixEngine.getAllUsers === 'function') {
      const allUsers = this.matrixEngine.getAllUsers();
      allUsers[user.unique_id] = {
        uniqueId: user.unique_id,
        email: user.email,
        walletAddress: user.wallet_address,
        referrerId: user.referrer_id,
        status: user.status,
        totalEarned: user.total_earned || 0,
        walletBalance: user.wallet_balance || 0,
        isRegistered: true,
        joinTimestamp: Date.now()
      };
      this.matrixEngine.saveAllUsers(allUsers);
    }

    return this.currentUser;
  }

  saveSession(uniqueId, remember = true) {
    if (!uniqueId || ['M8-ADMIN', 'ADMIN', 'M8-VIP001'].includes(uniqueId)) {
      return;
    }
    if (remember) {
      localStorage.setItem(this.SESSION_KEY, uniqueId);
    } else {
      sessionStorage.setItem(this.SESSION_KEY, uniqueId);
    }
  }

  logout() {
    this.currentUser = null;
    this.connectedWallet = null;
    sessionStorage.removeItem(this.SESSION_KEY);
    localStorage.removeItem(this.SESSION_KEY);
    localStorage.removeItem('matrix8_active_session_id_prod');
    sessionStorage.removeItem('matrix8_active_session_id_prod');
  }

  isLoggedIn() {
    const saved = localStorage.getItem(this.SESSION_KEY) || sessionStorage.getItem(this.SESSION_KEY);
    return !!this.currentUser || (!!saved && !['M8-ADMIN', 'ADMIN', 'M8-VIP001'].includes(saved));
  }

  getCurrentUser() {
    return this.currentUser;
  }
}

window.AuthService = AuthService;
